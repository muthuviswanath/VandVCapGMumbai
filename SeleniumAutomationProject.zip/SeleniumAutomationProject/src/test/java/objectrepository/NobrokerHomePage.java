package objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NobrokerHomePage {
	private WebDriver driver;
	
	private String baseURL = "https://www.nobroker.in";
	
    @FindBy(xpath = "//div[@id='navHeader']//div[text()='Log in']")
    private WebElement login_link;
    
    @FindBy(xpath = "//input[@type='tel'][@id='signUp-phoneNumber']")
    private WebElement login_phone_number;

    @FindBy(xpath = "//button[@id='signUpSubmit']")
    private WebElement Continue_button;
    
    @FindBy(xpath = "//img[@alt='hamburger']")
    private WebElement menu_link;
    
    @FindBy(xpath = "//a[contains(text(),'Painting & Cleaning')]")
    private WebElement painting_link;
    
    
    

    public NobrokerHomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }


	public WebElement getLogin_link() {
		return login_link;
	}

	public String getBaseURL() {
		return baseURL;
	}



	public WebElement getLogin_phone_number() {
		return login_phone_number;
	}




	public WebElement getContinue_button() {
		return Continue_button;
	}




	public WebElement getMenu_link() {
		return menu_link;
	}




	public WebElement getPainting_link() {
		return painting_link;
	}
    
    
}
